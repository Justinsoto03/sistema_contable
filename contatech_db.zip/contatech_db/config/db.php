<?php
$host = "localhost";
$user = "root";
$pass = ""; // Tu contraseña de MySQL (vacío por defecto en XAMPP)
$db   = "contatech_db";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>