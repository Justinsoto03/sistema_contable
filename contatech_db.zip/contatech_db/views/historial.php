<?php
session_start();
// 1. Conexión a la base de datos usando tu archivo db.php
include '../config/db.php'; 

// Verificamos que el usuario esté logueado. Si no, al login.
if (!isset($_SESSION['user_id'])) { 
    header("Location: login.php"); 
    exit(); 
}

$usuario_id = $_SESSION['user_id']; 

// 2. Traer los datos reales filtrados por el ID del usuario actual
try {
    $stmt = $pdo->prepare("SELECT * FROM movimientos WHERE usuario_id = :user_id ORDER BY fecha DESC");
    $stmt->execute([':user_id' => $usuario_id]);
    $movimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error al consultar: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial | Accounting System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --sidebar-color: #5d5fef; --bg-body: #f4f7f6; --success: #2ecc71; --danger: #e74c3c; }
        body { margin: 0; font-family: 'Inter', sans-serif; background-color: var(--bg-body); display: flex; height: 100vh; overflow: hidden; }
        .main-content { flex-grow: 1; overflow-y: auto; display: flex; flex-direction: column; }
        .top-bar { background: white; padding: 15px 30px; display: flex; justify-content: flex-end; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .content-body { padding: 40px; }
        .card-table { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 15px; color: #888; border-bottom: 2px solid #f0f0f0; font-size: 0.9rem; }
        td { padding: 15px; border-bottom: 1px solid #f8f8f8; font-size: 0.95rem; }
        .badge { padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; }
        .badge-ingreso { background: rgba(46, 204, 113, 0.1); color: var(--success); }
        .badge-egreso { background: rgba(231, 76, 60, 0.1); color: var(--danger); }
        .monto-ingreso { color: var(--success); font-weight: 600; }
        .monto-egreso { color: var(--danger); font-weight: 600; }

        /* Estilos para el menú de tres puntos */
        .options-menu { position: relative; display: inline-block; }
        .dots-btn { background: none; border: none; cursor: pointer; font-size: 1.2rem; color: #aaa; padding: 5px; transition: 0.3s; }
        .dots-btn:hover { color: #5d5fef; }
        .dropdown-content { 
            display: none; position: absolute; right: 0; background: white; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.1); border-radius: 8px; z-index: 10; min-width: 120px;
        }
        .dropdown-content a { 
            color: #e74c3c; padding: 10px 15px; text-decoration: none; 
            display: flex; align-items: center; gap: 8px; font-size: 0.85rem; font-weight: 600;
        }
        .dropdown-content a:hover { background: #fff5f5; }
        .show { display: block; }
    </style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <header class="top-bar">
             <span>Hola, <strong><?php echo $_SESSION['user_name']; ?></strong></span>
        </header>

        <div class="content-body">
            <h2 style="margin-top:0; margin-bottom: 25px;">Historial de Movimientos</h2>
            
            <?php if(isset($error)): ?>
                <p style="color:red;"><?php echo $error; ?></p>
            <?php endif; ?>

            <div class="card-table">
                <table>
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Descripción</th>
                            <th>Tipo</th>
                            <th>Monto</th>
                            <th style="text-align: center;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($movimientos) > 0): ?>
                            <?php foreach($movimientos as $m): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($m['fecha'])); ?></td>
                                <td><?php echo htmlspecialchars($m['descripcion']); ?></td>
                                <td>
                                    <span class="badge <?php echo (strtolower($m['tipo']) == 'ingreso') ? 'badge-ingreso' : 'badge-egreso'; ?>">
                                        <?php echo $m['tipo']; ?>
                                    </span>
                                </td>
                                <td class="<?php echo (strtolower($m['tipo']) == 'ingreso') ? 'monto-ingreso' : 'monto-egreso'; ?>">
                                    <?php echo (strtolower($m['tipo']) == 'ingreso' ? '+' : '-') . ' S/ ' . number_format($m['monto'], 2); ?>
                                </td>
                                <td style="text-align: center;">
                                    <div class="options-menu">
                                        <button class="dots-btn" onclick="toggleMenu(<?php echo $m['id']; ?>)">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <div id="menu-<?php echo $m['id']; ?>" class="dropdown-content">
                                            <a href="javascript:void(0)" onclick="confirmarBorrado(<?php echo $m['id']; ?>)">
                                                <i class="fas fa-trash-alt"></i> Borrar
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align:center; color:#999; padding: 50px;">
                                    <i class="fas fa-folder-open" style="font-size: 2rem; display: block; margin-bottom: 10px;"></i>
                                    No tienes movimientos registrados.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        function toggleMenu(id) {
            // Cierra cualquier otro menú abierto primero
            document.querySelectorAll('.dropdown-content').forEach(m => {
                if(m.id !== 'menu-'+id) m.classList.remove('show');
            });
            // Abre o cierra el menú actual
            document.getElementById('menu-' + id).classList.toggle('show');
        }

        function confirmarBorrado(id) {
            if (confirm('¿Estás seguro de que quieres eliminar este movimiento? Esta acción no se puede deshacer.')) {
                // Redirige al archivo de eliminación
                window.location.href = '../modules/eliminar_movimiento.php?id=' + id;
            }
        }

        // Cerrar el menú si el usuario hace clic fuera de él
        window.onclick = function(event) {
            if (!event.target.matches('.dots-btn') && !event.target.closest('.dots-btn')) {
                document.querySelectorAll('.dropdown-content').forEach(m => {
                    m.classList.remove('show');
                });
            }
        }
    </script>
</body>
</html>