<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Acceso | CONTATECH PERÚ</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <style>
        :root {
            --oro: #f39a00;
            --oscuro: #1a1a1a;
            --gris-claro: #f4f7f6;
        }

        body {
            background: var(--gris-claro);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Inter', sans-serif;
        }

        .main-container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 14px 28px rgba(0,0,0,0.1), 0 10px 10px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
            width: 850px;
            max-width: 100%;
            min-height: 500px; /* Reduje un poco la altura para que se vea más compacto */
        }

        .form-container {
            position: absolute;
            top: 0;
            height: 100%;
            transition: all 0.6s ease-in-out;
        }

        .sign-in-container { left: 0; width: 50%; z-index: 2; }
        .sign-up-container { left: 0; width: 50%; opacity: 0; z-index: 1; }

        .main-container.right-panel-active .sign-in-container { transform: translateX(100%); opacity: 0; }
        .main-container.right-panel-active .sign-up-container { transform: translateX(100%); opacity: 1; z-index: 5; animation: show 0.6s; }

        @keyframes show {
            0%, 49.99% { opacity: 0; z-index: 1; }
            50%, 100% { opacity: 1; z-index: 5; }
        }

        form {
            background-color: #FFFFFF;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 0 50px;
            height: 100%;
            text-align: center;
        }

        h1 { font-family: 'Playfair Display', serif; font-size: 1.8rem; margin-bottom: 15px; }

        input, select {
            background-color: #f1f1f1;
            border: 1px solid #eee;
            padding: 12px 15px;
            margin: 8px 0;
            width: 100%;
            border-radius: 8px;
            font-size: 0.9rem;
            box-sizing: border-box; /* Evita que el input se salga del borde */
        }

        .btn-submit {
            background-color: var(--oscuro);
            color: white;
            padding: 12px 40px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-transform: uppercase;
            cursor: pointer;
            margin-top: 15px;
            transition: 0.3s;
        }

        /* --- ESTILOS DEL PANEL NARANJA (EL PROBLEMA ESTABA AQUÍ) --- */
        .overlay-container {
            position: absolute;
            top: 0;
            left: 50%;
            width: 50%;
            height: 100%;
            overflow: hidden;
            transition: transform 0.6s ease-in-out;
            z-index: 100;
        }

        .main-container.right-panel-active .overlay-container { transform: translateX(-100%); }

        .overlay {
            background: var(--oro);
            color: #FFFFFF;
            position: relative;
            left: -100%;
            height: 100%;
            width: 200%;
            transform: translateX(0);
            transition: transform 0.6s ease-in-out;
        }

        .main-container.right-panel-active .overlay { transform: translateX(50%); }

        .overlay-panel {
            position: absolute;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 0 40px; /* Espaciado interno para que el texto no toque los bordes */
            text-align: center;
            top: 0;
            height: 100%;
            width: 50%; /* Ocupa la mitad del overlay total (200% / 2) */
            box-sizing: border-box; /* Fundamental para el padding */
        }

        .overlay-panel h1 { color: white; margin-bottom: 10px; }
        .overlay-panel p { 
            font-size: 0.95rem; 
            line-height: 1.5; 
            margin-bottom: 25px; 
            max-width: 100%; /* Asegura que el texto no se salga */
        }

        .overlay-left { transform: translateX(-20%); }
        .main-container.right-panel-active .overlay-left { transform: translateX(0); }

        .overlay-right { right: 0; transform: translateX(0); }
        .main-container.right-panel-active .overlay-right { transform: translateX(20%); }

        .btn-ghost {
            background-color: transparent;
            border: 2px solid #FFFFFF;
            color: #FFFFFF;
            border-radius: 25px;
            padding: 10px 35px;
            cursor: pointer;
            text-transform: uppercase;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-ghost:hover { background: white; color: var(--oro); }
    </style>
</head>
<body>

<div class="main-container" id="container">
    <div class="form-container sign-up-container">
        <form action="../controllers/auth_controller.php?action=register" method="POST">
            <h1>Crear Cuenta</h1>
            <input type="text" name="nombre" placeholder="Nombre Completo" required />
            <input type="email" name="email" placeholder="Correo Electrónico" required />
            <input type="text" name="tipo de negocio" placeholder="Negocio" required />

            <input type="password" name="password" placeholder="Contraseña" required />
            <button type="submit" class="btn-submit">Registrarme</button>
        </form>
    </div>

    <div class="form-container sign-in-container">
        <form action="../controllers/auth_controller.php?action=login" method="POST">
            <h1>Inicia Sesión</h1>
            <input type="email" name="email" placeholder="Correo Electrónico" required />
            <input type="password" name="password" placeholder="Contraseña" required />
            <button type="submit" class="btn-submit">Entrar</button>
        </form>
    </div>

    <div class="overlay-container">
        <div class="overlay">
            <div class="overlay-panel overlay-left">
                <h1>¿Ya eres parte?</h1>
                <p>Inicia sesión para acceder a tu panel de control y ver tus finanzas.</p>
                <button class="btn-ghost" id="signIn">Ir al Login</button>
            </div>
            <div class="overlay-panel overlay-right">
                <h1>¿Nuevo aquí?</h1>
                <p>Crea tu cuenta hoy y lleva tu empresa al siguiente nivel con nosotros.</p>
                <button class="btn-ghost" id="signUp">Registrarme</button>
            </div>
        </div>
    </div>
</div>

<script>
    const signUpButton = document.getElementById('signUp');
    const signInButton = document.getElementById('signIn');
    const container = document.getElementById('container');

    signUpButton.addEventListener('click', () => {
        container.classList.add("right-panel-active");
    });

    signInButton.addEventListener('click', () => {
        container.classList.remove("right-panel-active");
    });
</script>

</body>
</html>