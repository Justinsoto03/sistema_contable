<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro | CONTATECH PERÚ</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <style>
        .auth-page {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--gris-suave);
        }
        .auth-card {
            background: white;
            padding: 50px;
            width: 100%;
            max-width: 450px;
            box-shadow: var(--sombra);
            text-align: center;
        }
        .auth-card h2 {
            font-family: var(--fuente-titulo);
            font-size: 2rem;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        .auth-card p {
            color: #888;
            font-size: 0.9rem;
            margin-bottom: 30px;
        }
        .form-group {
            text-align: left;
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
            font-weight: 600;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #eee;
            font-family: var(--fuente-cuerpo);
            transition: 0.3s;
        }
        .form-group input:focus {
            border-color: var(--oro);
            outline: none;
        }
        .btn-auth {
            width: 100%;
            background: var(--oro);
            color: white;
            border: none;
            padding: 15px;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 1px;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 10px;
        }
        .btn-auth:hover { background: #a3895d; }
        .auth-footer { margin-top: 25px; font-size: 0.85rem; }
        .auth-footer a { color: var(--oro); text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="auth-page">
        <div class="auth-card">
            <h2>Crear Cuenta</h2>
            <p>Únete a la nueva era de contabilidad estratégica.</p>
            
            <form action="../controllers/auth_controller.php?action=register" method="POST">
                <div class="form-group">
                    <label>Nombre Completo</label>
                    <input type="text" name="nombre" required placeholder="Ej. Juan Pérez">
                </div>
                <div class="form-group">
                    <label>Correo Electrónico</label>
                    <input type="email" name="email" required placeholder="tu@email.com">
                </div>
                <div class="form-group">
                    <label>Contraseña</label>
                    <input type="password" name="password" required placeholder="••••••••">
                </div>
                <button type="submit" class="btn-auth">Registrarme</button>
            </form>
            
            <div class="auth-footer">
                ¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí</a>
            </div>
        </div>
    </div>
</body>
</html>