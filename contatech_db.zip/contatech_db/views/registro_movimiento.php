<?php
session_start();
// 1. Verificamos sesión
if (!isset($_SESSION['user_name'])) { 
    header("Location: login.php"); 
    exit(); 
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro | Accounting System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --sidebar-color: #5d5fef; --bg-body: #f4f7f6; --success: #2ecc71; --danger: #e74c3c; }
        body { margin: 0; display: flex; height: 100vh; background: var(--bg-body); font-family: 'Inter', sans-serif; overflow: hidden; }
        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .top-bar { background: white; padding: 15px 30px; display: flex; justify-content: flex-end; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .content-body { padding: 40px; }
        .grid-forms { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
        .card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border-top: 5px solid; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 0.85rem; color: #666; }
        .form-group input, .form-group select { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-family: inherit; }
        .btn { width: 100%; padding: 15px; border: none; border-radius: 8px; color: white; font-weight: 600; cursor: pointer; margin-top: 10px; transition: 0.3s; }
        .btn:hover { opacity: 0.8; transform: translateY(-1px); }
    </style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <header class="top-bar">
            <div style="display: flex; align-items: center; gap: 10px;">
                <span>Hola, <strong><?php echo $_SESSION['user_name']; ?></strong></span>
                <img src="https://ui-avatars.com/api/?name=<?php echo $_SESSION['user_name']; ?>&background=5d5fef&color=fff" style="width:35px; border-radius:50%;">
            </div>
        </header>

        <div class="content-body">
            <h2 style="margin-top:0; margin-bottom: 30px;">Registro de Movimiento</h2>
            
            <div class="grid-forms">
                <div class="card" style="border-color: #2ecc71;">
                    <h3 style="color: #2ecc71; margin-top:0;"><i class="fas fa-arrow-up"></i> Registrar Ingreso</h3>
                    <form action="../modules/insertar.php" method="POST">
                        <input type="hidden" name="tipo" value="Ingreso">
                        <div class="form-group">
                            <label>Fecha</label>
                            <input type="date" name="fecha" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Cuenta de Destino</label>
                            <select name="cuenta" required>
                                <option value="Caja Chica">Caja Chica</option>
                                <option value="Banco BCP">Banco BCP</option>
                                <option value="Efectivo">Efectivo</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Monto</label>
                            <input type="number" name="monto" step="0.01" placeholder="0.00" required>
                        </div>
                        <div class="form-group">
                            <label>Descripción</label>
                            <input type="text" name="descripcion" placeholder="Ej. Pago de cliente" required>
                        </div>
                        <button type="submit" class="btn" style="background: #2ecc71;">Guardar Ingreso</button>
                    </form>
                </div>

                <div class="card" style="border-color: #e74c3c;">
    <h3 style="color: #e74c3c; margin-top:0;"><i class="fas fa-arrow-down"></i> Registrar Egreso</h3>
    <form action="../modules/insertar.php" method="POST">
        <input type="hidden" name="tipo" value="egreso">
        
        <div class="form-group">
            <label>Monto</label>
            <input type="number" name="monto" step="0" placeholder="" required>
        </div>
        <div class="form-group">
            <label>Descripción</label>
            <input type="text" name="descripcion" placeholder="Ej. Pago de luz" required>
        </div>
        <div class="form-group">
            <label>Fecha</label>
            <input type="date" name="fecha" value="<?php echo date('Y-m-d'); ?>" required>
        </div>
        <button type="submit" class="btn" style="background: #e74c3c;">Guardar Egreso</button>
    </form>
</div>
            </div>
        </div>
    </main>
</body>
</html>