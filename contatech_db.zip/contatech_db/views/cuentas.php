<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}
// Detectamos la página actual para marcar el menú activo
$pagina_actual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cuentas | Accounting System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root { 
            --sidebar-color: #5d5fef; 
            --bg-body: #f4f7f6; 
            --text-white: #ffffff;
            --success: #2ecc71;
            --danger: #e74c3c;
        }
        body { margin: 0; font-family: 'Inter', sans-serif; background-color: var(--bg-body); display: flex; height: 100vh; overflow: hidden; }

        /* --- SIDEBAR --- */
        .sidebar { width: 240px; background-color: var(--sidebar-color); color: var(--text-white); display: flex; flex-direction: column; padding-top: 20px; flex-shrink: 0; }
        .sidebar-header { padding: 20px; font-weight: 600; font-size: 1.1rem; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 20px; }
        .nav-menu { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; height: 100%; }
        .nav-item { padding: 15px 25px; display: flex; align-items: center; cursor: pointer; transition: 0.3s; color: rgba(255,255,255,0.8); text-decoration: none; }
        .nav-item i:first-child { margin-right: 15px; width: 20px; text-align: center; }
        .nav-item:hover, .nav-item.active { background-color: rgba(255,255,255,0.2); color: white; }

        /* --- SUBMENU TRANSACCIONES --- */
        .submenu { display: none; list-style: none; padding: 0; background: rgba(0, 0, 0, 0.1); }
        .submenu.show { display: block; }
        .sub-nav-item { padding: 12px 25px 12px 50px; display: flex; align-items: center; color: rgba(255, 255, 255, 0.7); text-decoration: none; font-size: 0.85rem; }
        .sub-nav-item:hover { color: white; background: rgba(255, 255, 255, 0.1); }
        .arrow-icon { margin-left: auto; font-size: 0.7rem; transition: 0.3s; }
        .rotate { transform: rotate(90deg); }

        /* --- MAIN CONTENT --- */
        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .top-bar { background: white; padding: 15px 30px; display: flex; justify-content: flex-end; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .user-profile { display: flex; align-items: center; gap: 10px; }
        .user-profile img { width: 35px; border-radius: 50%; border: 2px solid var(--sidebar-color); }

        /* --- TABLA Y BUSCADOR --- */
        .content-body { padding: 40px; }
        .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .btn-add { background: var(--sidebar-color); color: white; padding: 12px 24px; border-radius: 30px; border: none; cursor: pointer; font-weight: 600; box-shadow: 0 4px 10px rgba(93, 95, 239, 0.3); }
        
        .card-table { background: white; border-radius: 12px; padding: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        .search-container { display: flex; gap: 10px; margin-bottom: 25px; }
        .search-input { flex-grow: 1; padding: 12px; border: 1px solid #ddd; border-radius: 8px; outline: none; }
        .btn-search { background: var(--success); color: white; border: none; padding: 0 25px; border-radius: 8px; cursor: pointer; font-weight: 600; }

        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 15px; border-bottom: 2px solid #f0f0f0; color: #888; font-size: 0.75rem; text-transform: uppercase; }
        td { padding: 18px 15px; border-bottom: 1px solid #f8f8f8; font-size: 0.95rem; }
        .status-positive { color: var(--success); font-weight: 600; }
        .status-negative { color: var(--danger); font-weight: 600; }

        /* --- DROPDOWN ACCIONES --- */
        .actions-container { position: relative; display: inline-block; }
        .dots-btn { background: none; border: none; color: #ccc; cursor: pointer; font-size: 1.2rem; }
        .dropdown-content { display: none; position: absolute; right: 0; background: white; min-width: 120px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); z-index: 10; border-radius: 8px; }
        .dropdown-content.show { display: block; }
        .dropdown-content a { color: #333; padding: 12px 16px; text-decoration: none; display: block; font-size: 0.85rem; }
        .dropdown-content a:hover { background: #f8f9fa; }
        .dropdown-content a.delete { color: var(--danger); }

        /* --- MODAL --- */
        .modal { display: none; position: fixed; z-index: 100; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); align-items: center; justify-content: center; backdrop-filter: blur(4px); }
        .modal-content { background: white; padding: 40px; border-radius: 16px; width: 400px; }
        .modal-body input { width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; }
        .btn-save { width: 100%; background: var(--sidebar-color); color: white; border: none; padding: 14px; border-radius: 8px; font-weight: 600; cursor: pointer; }
    </style>
</head>
<body>

    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <header class="top-bar">
            <div class="user-profile">
                <span>Hola, <strong><?php echo $_SESSION['user_name']; ?></strong></span>
                <img src="https://ui-avatars.com/api/?name=<?php echo $_SESSION['user_name']; ?>&background=5d5fef&color=fff" alt="User">
            </div>
        </header>

        <div class="content-body">
            <div class="section-header">
                <h2>Cuentas Bancarias</h2>
                <button class="btn-add" onclick="toggleModal()"><i class="fas fa-plus"></i> Agregar Cuenta</button>
            </div>

            <div class="card-table">
                <div class="search-container">
                    <input type="text" id="searchInput" class="search-input" placeholder="Buscar banco...">
                    <button class="btn-search" onclick="filterTable()">Buscar</button>
                </div>

                <table id="accountsTable">
                    <thead>
                        <tr>
                            <th>Nombre del Banco</th>
                            <th>Saldo Actual</th>
                            <th>Fecha Registro</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="bank-name"></td>
                            <td class="status-positive"></td>
                            <td></td>
                            <td>
                                <div class="actions-container">
                                    <button class="dots-btn" onclick="toggleActionDropdown(this)"><i class="fas fa-ellipsis-v"></i></button>
                                    <div class="dropdown-content">
                                        <a href="#" onclick="editRow(this)"><i class="fas fa-edit"></i> Editar</a>
                                        <a href="#" class="delete" onclick="deleteRow(this)"><i class="fas fa-trash"></i> Eliminar</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <div id="accountModal" class="modal">
        <div class="modal-content">
            <h3>Nueva Cuenta</h3>
            <div class="modal-body">
                <input type="text" id="newBankName" placeholder="Nombre del Banco">
                <input type="number" id="newBalance" placeholder="Saldo Inicial">
                <button class="btn-save" onclick="addAccount()">Guardar</button>
                <button onclick="toggleModal()" style="width:100%; background:none; border:none; color:#888; margin-top:10px; cursor:pointer;">Cancelar</button>
            </div>
        </div>
    </div>

    <script>
        // 1. Menú Lateral (Sidebar)
        function toggleSidebarDropdown() {
            document.getElementById("submenuTrans").classList.toggle("show");
            document.getElementById("arrow").classList.toggle("rotate");
        }

        // 2. Buscador de la tabla
        function filterTable() {
            let input = document.getElementById("searchInput").value.toLowerCase();
            let rows = document.querySelectorAll("#accountsTable tbody tr");
            rows.forEach(row => {
                let name = row.querySelector(".bank-name").innerText.toLowerCase();
                row.style.display = name.includes(input) ? "" : "none";
            });
        }

        // 3. Modal
        function toggleModal() {
            let modal = document.getElementById("accountModal");
            modal.style.display = (modal.style.display === "flex") ? "none" : "flex";
        }

        // 4. Agregar Cuenta
        function addAccount() {
            let name = document.getElementById("newBankName").value;
            let balance = document.getElementById("newBalance").value;
            if(!name || !balance) return alert("Completa los campos");

            let table = document.querySelector("#accountsTable tbody");
            let newRow = `<tr>
                <td class="bank-name">${name}</td>
                <td class="status-positive">$ ${parseFloat(balance).toLocaleString()}</td>
                <td>${new Date().toLocaleDateString()}</td>
                <td>
                    <div class="actions-container">
                        <button class="dots-btn" onclick="toggleActionDropdown(this)"><i class="fas fa-ellipsis-v"></i></button>
                        <div class="dropdown-content">
                            <a href="#" onclick="editRow(this)"><i class="fas fa-edit"></i> Editar</a>
                            <a href="#" class="delete" onclick="deleteRow(this)"><i class="fas fa-trash"></i> Eliminar</a>
                        </div>
                    </div>
                </td>
            </tr>`;
            table.insertAdjacentHTML('beforeend', newRow);
            toggleModal();
        }

        // 5. Menú de Tres Puntos (Acciones)
        function toggleActionDropdown(btn) {
            document.querySelectorAll('.dropdown-content').forEach(d => d.classList.remove('show'));
            btn.nextElementSibling.classList.toggle("show");
        }

        window.onclick = function(event) {
            if (!event.target.matches('.dots-btn') && !event.target.matches('.fa-ellipsis-v')) {
                document.querySelectorAll('.dropdown-content').forEach(d => d.classList.remove('show'));
            }
        }

        // 6. Editar y Eliminar
        function deleteRow(link) {
            if(confirm("¿Seguro?")) link.closest('tr').remove();
        }

        function editRow(link) {
            let row = link.closest('tr');
            let name = row.querySelector(".bank-name").innerText;
            let newName = prompt("Nuevo nombre:", name);
            if(newName) row.querySelector(".bank-name").innerText = newName;
        }
    </script>
</body>
</html>