<?php
session_start();
if (!isset($_SESSION['user_name'])) { header("Location: login.php"); exit(); }
$pagina_actual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transferencias | Accounting System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root { --sidebar-color: #5d5fef; --bg-body: #f4f7f6; --transfer: #3498db; }
        body { margin: 0; font-family: 'Inter', sans-serif; background-color: var(--bg-body); display: flex; height: 100vh; overflow: hidden; }

        /* --- SIDEBAR --- */
        .sidebar { width: 240px; background-color: var(--sidebar-color); color: white; display: flex; flex-direction: column; padding-top: 20px; flex-shrink: 0; }
        .sidebar-header { padding: 20px; font-weight: 600; font-size: 1.1rem; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 20px; }
        .nav-item { padding: 15px 25px; display: flex; align-items: center; cursor: pointer; color: rgba(255,255,255,0.8); text-decoration: none; transition: 0.3s; }
        .nav-item:hover, .nav-item.active { background-color: rgba(255,255,255,0.2); color: white; }
        .nav-item i { margin-right: 15px; width: 20px; text-align: center; }

        .submenu { display: none; list-style: none; padding: 0; background: rgba(0, 0, 0, 0.1); }
        .submenu.show { display: block; }
        .sub-nav-item { padding: 12px 25px 12px 50px; display: flex; align-items: center; color: rgba(255, 255, 255, 0.7); text-decoration: none; font-size: 0.85rem; }
        .sub-nav-item.active-sub { color: white; background: rgba(255, 255, 255, 0.1); }
        .arrow-icon { margin-left: auto; font-size: 0.7rem; transition: 0.3s; }
        .rotate { transform: rotate(90deg); }

        /* --- MAIN CONTENT --- */
        .main-content { flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; }
        .top-bar { background: white; padding: 15px 30px; display: flex; justify-content: flex-end; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .content-body { padding: 40px; }
        .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .btn-add { background: var(--transfer); color: white; padding: 12px 24px; border-radius: 30px; border: none; cursor: pointer; font-weight: 600; }
        
        .card-table { background: white; border-radius: 12px; padding: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 15px; border-bottom: 2px solid #f0f0f0; color: #888; font-size: 0.75rem; text-transform: uppercase; }
        td { padding: 18px 15px; border-bottom: 1px solid #f8f8f8; font-size: 0.95rem; }
        .amount-blue { color: var(--transfer); font-weight: 600; }

        /* --- ACCIONES --- */
        .actions-container { position: relative; }
        .dots-btn { background: none; border: none; color: #ccc; cursor: pointer; font-size: 1.1rem; }
        .dropdown-actions { display: none; position: absolute; right: 0; background: white; min-width: 120px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); z-index: 10; border-radius: 8px; border: 1px solid #eee; }
        .dropdown-actions.show { display: block; }
        .dropdown-actions a { color: #333; padding: 10px 15px; text-decoration: none; display: block; font-size: 0.85rem; }

        /* --- MODAL --- */
        .modal { display: none; position: fixed; z-index: 100; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); align-items: center; justify-content: center; backdrop-filter: blur(4px); }
        .modal-content { background: white; padding: 30px; border-radius: 16px; width: 400px; }
        .modal-body label { display: block; margin-bottom: 5px; font-size: 0.85rem; color: #666; }
        .modal-body input, .modal-body select { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; }
        .btn-save { width: 100%; background: var(--transfer); color: white; border: none; padding: 14px; border-radius: 8px; font-weight: 600; cursor: pointer; }
    </style>
</head>
<body>

    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <header class="top-bar">
            <div class="user-profile">
                <span>Hola, <strong><?php echo $_SESSION['user_name']; ?></strong></span>
                <img src="https://ui-avatars.com/api/?name=<?php echo $_SESSION['user_name']; ?>&background=3498db&color=fff" style="width:35px; border-radius:50%; margin-left:10px;">
            </div>
        </header>

        <div class="content-body">
            <div class="section-header">
                <h2>Transferencias entre Cuentas</h2>
                <button class="btn-add" onclick="toggleModal()"><i class="fas fa-sync-alt"></i> Nueva Transferencia</button>
            </div>

            <div class="card-table">
                <table id="transfTable">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Origen</th>
                            <th>Destino</th>
                            <th>Descripción</th>
                            <th>Monto</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="td-fecha">17/12/2025</td>
                            <td class="td-origen">BCP Negocios</td>
                            <td class="td-destino">Caja Chica</td>
                            <td class="td-desc">Reposición de efectivo</td>
                            <td class="amount-blue">$ <span class="val-monto">200.00</span></td>
                            <td>
                                <div class="actions-container">
                                    <button class="dots-btn" onclick="toggleActions(this)"><i class="fas fa-ellipsis-v"></i></button>
                                    <div class="dropdown-actions">
                                        <a href="javascript:void(0)" onclick="editTransf(this)"><i class="fas fa-edit"></i> Editar</a>
                                        <a href="javascript:void(0)" style="color:red;" onclick="deleteTransf(this)"><i class="fas fa-trash"></i> Eliminar</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <div id="transfModal" class="modal">
        <div class="modal-content">
            <h3 id="modalTitle">Nueva Transferencia</h3>
            <div class="modal-body">
                <label>Fecha</label>
                <input type="date" id="inputFecha">
                <label>Cuenta Origen</label>
                <select id="inputOrigen">
                    <option value="BCP Negocios">BCP Negocios</option>
                    <option value="Caja Chica">Caja Chica</option>
                </select>
                <label>Cuenta Destino</label>
                <select id="inputDestino">
                    <option value="Caja Chica">Caja Chica</option>
                    <option value="BCP Negocios">BCP Negocios</option>
                </select>
                <label>Descripción</label>
                <input type="text" id="inputDesc" placeholder="Motivo del movimiento">
                <label>Monto</label>
                <input type="number" id="inputMonto" placeholder="0.00">
                <button class="btn-save" onclick="saveTransf()">Ejecutar Transferencia</button>
                <button onclick="toggleModal()" style="width:100%; background:none; border:none; color:#999; margin-top:10px; cursor:pointer;">Cancelar</button>
            </div>
        </div>
    </div>

    <script>
        let editandoFila = null;

        window.onload = function() {
            document.getElementById('inputFecha').value = new Date().toISOString().split('T')[0];
        };

        function toggleSidebar() {
            document.getElementById("submenuTrans").classList.toggle("show");
            document.getElementById("arrow").classList.toggle("rotate");
        }

        function toggleModal() {
            const modal = document.getElementById("transfModal");
            modal.style.display = (modal.style.display === "flex") ? "none" : "flex";
            if(modal.style.display === "none") {
                document.getElementById("modalTitle").innerText = "Nueva Transferencia";
                document.getElementById("inputDesc").value = "";
                document.getElementById("inputMonto").value = "";
                editandoFila = null;
            }
        }

        function toggleActions(btn) {
            document.querySelectorAll('.dropdown-actions').forEach(el => el.classList.remove('show'));
            btn.nextElementSibling.classList.toggle('show');
        }

        function saveTransf() {
            const fecha = document.getElementById("inputFecha").value;
            const origen = document.getElementById("inputOrigen").value;
            const destino = document.getElementById("inputDestino").value;
            const desc = document.getElementById("inputDesc").value;
            const monto = document.getElementById("inputMonto").value;

            if(!desc || !monto) return alert("Completa los datos");
            if(origen === destino) return alert("La cuenta origen y destino no pueden ser iguales");

            if(editandoFila) {
                editandoFila.querySelector(".td-fecha").innerText = fecha;
                editandoFila.querySelector(".td-origen").innerText = origen;
                editandoFila.querySelector(".td-destino").innerText = destino;
                editandoFila.querySelector(".td-desc").innerText = desc;
                editandoFila.querySelector(".val-monto").innerText = parseFloat(monto).toFixed(2);
            } else {
                const tabla = document.querySelector("#transfTable tbody");
                const row = `<tr>
                    <td class="td-fecha">${fecha}</td>
                    <td class="td-origen">${origen}</td>
                    <td class="td-destino">${destino}</td>
                    <td class="td-desc">${desc}</td>
                    <td class="amount-blue">$ <span class="val-monto">${parseFloat(monto).toFixed(2)}</span></td>
                    <td>
                        <div class="actions-container">
                            <button class="dots-btn" onclick="toggleActions(this)"><i class="fas fa-ellipsis-v"></i></button>
                            <div class="dropdown-actions">
                                <a href="javascript:void(0)" onclick="editTransf(this)"><i class="fas fa-edit"></i> Editar</a>
                                <a href="javascript:void(0)" style="color:red;" onclick="deleteTransf(this)"><i class="fas fa-trash"></i> Eliminar</a>
                            </div>
                        </div>
                    </td>
                </tr>`;
                tabla.insertAdjacentHTML('afterbegin', row);
            }
            toggleModal();
        }

        function deleteTransf(link) {
            if(confirm("¿Eliminar este registro?")) link.closest('tr').remove();
        }

        function editTransf(link) {
            editandoFila = link.closest('tr');
            document.getElementById("modalTitle").innerText = "Editar Transferencia";
            document.getElementById("inputFecha").value = editandoFila.querySelector(".td-fecha").innerText;
            document.getElementById("inputOrigen").value = editandoFila.querySelector(".td-origen").innerText;
            document.getElementById("inputDestino").value = editandoFila.querySelector(".td-destino").innerText;
            document.getElementById("inputDesc").value = editandoFila.querySelector(".td-desc").innerText;
            document.getElementById("inputMonto").value = editandoFila.querySelector(".val-monto").innerText;
            toggleModal();
        }
    </script>
</body>
</html> 