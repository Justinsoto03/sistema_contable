<?php
session_start();
include '../config/db.php'; // Tu archivo de conexión PDO

// 1. Verificación de seguridad
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$uid = $_SESSION['user_id']; // ID del usuario actual

// 2. Obtener Totales para las tarjetas (Cards)
// Sumar Ingresos
$stmtI = $pdo->prepare("SELECT SUM(monto) as total FROM movimientos WHERE usuario_id = ? AND tipo = 'ingreso'");
$stmtI->execute([$uid]);
$totalIngresos = $stmtI->fetch()['total'] ?? 0;

// Sumar Egresos
$stmtE = $pdo->prepare("SELECT SUM(monto) as total FROM movimientos WHERE usuario_id = ? AND tipo = 'egreso'");
$stmtE->execute([$uid]);
$totalEgresos = $stmtE->fetch()['total'] ?? 0;

$saldo = $totalIngresos - $totalEgresos;

// 3. Obtener Datos para el Gráfico (Análisis Mensual)
// Inicializamos arreglos con 12 ceros (uno por cada mes)
$ingresosMes = array_fill(1, 12, 0);
$egresosMes = array_fill(1, 12, 0);

// Consulta para traer sumas agrupadas por mes
$stmtGrafico = $pdo->prepare("SELECT MONTH(fecha) as mes, tipo, SUM(monto) as total 
                              FROM movimientos 
                              WHERE usuario_id = ? 
                              GROUP BY MONTH(fecha), tipo");
$stmtGrafico->execute([$uid]);
$datosGrafico = $stmtGrafico->fetchAll(PDO::FETCH_ASSOC);

foreach ($datosGrafico as $row) {
    if ($row['tipo'] == 'ingreso') {
        $ingresosMes[(int)$row['mes']] = (float)$row['total'];
    } else {
        $egresosMes[(int)$row['mes']] = (float)$row['total'];
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard | Accounting System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --sidebar-color: #5d5fef; --bg-body: #f4f7f6; }
        body { margin: 0; font-family: 'Inter', sans-serif; background-color: var(--bg-body); display: flex; height: 100vh; overflow: hidden; }
        .main-content { flex-grow: 1; overflow-y: auto; display: flex; flex-direction: column; }
        .content-body { padding: 30px; }
        .grid-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        .chart-container { background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    </style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>

    <main class="main-content">
        <div class="content-body">
            <h2>Panel de Control</h2>
            
            <div class="grid-stats">
                <div class="stat-card">
                    <small>Ingresos Totales</small>
                    <h3 style="color: #2ecc71;">S/ <?php echo number_format($totalIngresos, 2); ?></h3>
                </div>
                <div class="stat-card">
                    <small>Gastos Totales</small>
                    <h3 style="color: #e74c3c;">S/ <?php echo number_format($totalEgresos, 2); ?></h3>
                </div>
                <div class="stat-card">
                    <small>Saldo Actual</small>
                    <h3>S/ <?php echo number_format($saldo, 2); ?></h3>
                </div>
            </div>

            <div class="chart-container">
                <canvas id="myChart"></canvas>
            </div>
        </div>
    </main>

    <script>
        const ctx = document.getElementById('myChart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                datasets: [{
                    label: 'Ingresos',
                    data: <?php echo json_encode(array_values($ingresosMes)); ?>,
                    backgroundColor: '#5d5fef'
                }, {
                    label: 'Gastos',
                    data: <?php echo json_encode(array_values($egresosMes)); ?>,
                    backgroundColor: '#e74c3c'
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true } } }
        });
    </script>
</body>
</html>