<?php
require_once '../config/db.php';
session_start();

$action = $_GET['action'] ?? '';

// --- LÓGICA DE CERRAR SESIÓN ---
if ($action === 'logout') {
    // 1. Limpiamos todas las variables de sesión
    $_SESSION = array();

    // 2. Si se desea destruir la sesión completamente, también se borra la cookie de sesión
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // 3. Finalmente, se destruye la sesión
    session_destroy();
    
    // 4. Redirigimos al index principal usando la ruta absoluta para evitar fallos
    header("Location: http://localhost/contatech_db/index.php");
    exit();
}

// --- LÓGICA DE REGISTRO ---
if ($action === 'register') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $tipo_negocio = $_POST['tipo_negocio']; // Asegúrate de que tu formulario tenga este name
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    try {
        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, tipo_negocio, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nombre, $email, $tipo_negocio, $password]);
        header("Location: http://localhost/contatech_db/views/login.php?msg=success");
        exit();
    } catch (PDOException $e) {
        header("Location: http://localhost/contatech_db/views/login.php?mode=signup&error=exists");
        exit();
    }
}

// --- LÓGICA DE LOGIN ---
if ($action === 'login') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['nombre'];
        $_SESSION['user_negocio'] = $user['tipo_negocio'];
        
        header("Location: http://localhost/contatech_db/views/dashboard.php");
        exit();
    } else {
        header("Location: http://localhost/contatech_db/views/login.php?error=1");
        exit();
    }
}
?>