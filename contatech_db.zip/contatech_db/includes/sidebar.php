<?php $pagina_actual = basename($_SERVER['PHP_SELF']); ?>
<style>
    /* Estilos del Sidebar */
    .sidebar { width: 240px; background-color: #f39a00; color: white; display: flex; flex-direction: column; flex-shrink: 0; height: 100vh; }
    .sidebar-header { padding: 25px; font-weight: 600; font-size: 1.2rem; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
    .nav-menu { display: flex; flex-direction: column; height: 100%; padding: 10px 0; }
    .nav-item { padding: 15px 25px; color: rgba(255, 255, 255, 1); text-decoration: none; display: flex; align-items: center; gap: 12px; }
    .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.1); color: white; }
    .submenu { display: none; list-style: none; padding-left: 20px; }
    .submenu.show { display: block; }
    .sub-nav-item { padding: 10px 25px; color: rgba(255, 255, 255, 1); text-decoration: none; display: block; font-size: 0.9rem; }
    .active-sub { color: white; font-weight: 600; }
    .rotate { transform: rotate(90deg); transition: 0.3s; }

    /* --- ESTILOS DEL CHATBOT --- */
    #chatbot-launcher {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 60px;
        height: 60px;
        background-color: #5d5fef;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
        font-size: 24px;
        cursor: pointer;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        z-index: 9999;
        transition: 0.3s;
    }
    #chatbot-launcher:hover { transform: scale(1.1); background-color: #4a4cd9; }

    #chatbot-window {
        position: fixed;
        bottom: 90px;
        right: 20px;
        width: 320px;
        height: 450px;
        background: white;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        display: none;
        flex-direction: column;
        z-index: 9999;
        overflow: hidden;
        font-family: 'Inter', sans-serif;
    }
    .chat-header { background: #5d5fef; color: white; padding: 15px; display: flex; justify-content: space-between; align-items: center; }
    .chat-header h4 { margin: 0; font-size: 1rem; }
    .chat-header button { background: none; border: none; color: white; font-size: 20px; cursor: pointer; }
    
    #chat-messages { flex-grow: 1; padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; background: #f9f9f9; }
    .msg { padding: 10px 14px; border-radius: 15px; max-width: 80%; font-size: 0.85rem; line-height: 1.4; }
    .bot { background: #e0e0e0; color: #333; align-self: flex-start; border-bottom-left-radius: 2px; }
    .user { background: #5d5fef; color: white; align-self: flex-end; border-bottom-right-radius: 2px; }
    
    .chat-input-area { padding: 15px; background: white; border-top: 1px solid #eee; display: flex; gap: 10px; }
    .chat-input-area input { flex-grow: 1; border: 1px solid #ddd; padding: 10px; border-radius: 20px; outline: none; font-size: 0.85rem; }
    .chat-input-area button { background: #5d5fef; border: none; color: white; width: 35px; height: 35px; border-radius: 50%; cursor: pointer; }
</style>

<aside class="sidebar">
    <div class="sidebar-header">ContaTech Perú</div>
    <nav class="nav-menu">
        <a href="dashboard.php" class="nav-item <?= $pagina_actual == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-th-large"></i> Dashboard
        </a>
        <a href="cuentas.php" class="nav-item <?= $pagina_actual == 'cuentas.php' ? 'active' : '' ?>">
            <i class="fas fa-wallet"></i> Cuentas
        </a>
        <a href="registro_movimiento.php" class="nav-item <?= $pagina_actual == 'registro_movimiento.php' ? 'active' : '' ?>">
            <i class="fas fa-pen-to-square"></i> Registro de Movimiento
        </a>
        <div>
            <a href="javascript:void(0)" class="nav-item" onclick="toggleDropdown()">
                <i class="fas fa-exchange-alt"></i> Transacciones 
                <i class="fas fa-chevron-right arrow-icon <?= in_array($pagina_actual, ['gastos.php', 'ingresos.php', 'transferencias.php']) ? 'rotate' : '' ?>" id="arrow"></i>
            </a>
            <ul class="submenu <?= in_array($pagina_actual, ['gastos.php', 'ingresos.php', 'transferencias.php']) ? 'show' : '' ?>" id="submenuTrans">
                <li><a href="gastos.php" class="sub-nav-item <?= $pagina_actual == 'gastos.php' ? 'active-sub' : '' ?>">Gastos</a></li>
                <li><a href="ingresos.php" class="sub-nav-item <?= $pagina_actual == 'ingresos.php' ? 'active-sub' : '' ?>">Ingresos</a></li>
                <li><a href="transferencias.php" class="sub-nav-item <?= $pagina_actual == 'transferencias.php' ? 'active-sub' : '' ?>">Transferencias</a></li>
            </ul>
        </div>
        <a href="historial.php" class="nav-item <?= $pagina_actual == 'historial.php' ? 'active' : '' ?>">
            <i class="fas fa-history"></i> Historial
        </a>
        <a href="../controllers/auth_controller.php?action=logout" class="nav-item" style="margin-top: auto; padding-bottom: 25px; color: #ffcccc;">
            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
        </a>
    </nav>
</aside>

<div id="chatbot-launcher" onclick="toggleChat()">
    <i class="fas fa-robot"></i>
</div>

<div id="chatbot-window">
    <div class="chat-header">
        <h4><i class="fas fa-robot"></i> Asistente Contable</h4>
        <button onclick="toggleChat()">&times;</button>
    </div>
    <div id="chat-messages">
        <div class="msg bot">
            ¡Hola <strong><?php echo $_SESSION['user_name'] ?? 'Usuario'; ?></strong>! 👋 Soy tu asistente. ¿Quieres saber tu saldo o ver tus últimos movimientos?
        </div>
    </div>
    <div class="chat-input-area">
        <input type="text" id="user-input" placeholder="Escribe un mensaje..." onkeypress="handleKeyPress(event)">
        <button onclick="sendMessage()"><i class="fas fa-paper-plane"></i></button>
    </div>
</div>

<script>
    // Función para el Sidebar
    function toggleDropdown() {
        const sub = document.getElementById("submenuTrans");
        const arr = document.getElementById("arrow");
        sub.classList.toggle("show");
        arr.classList.toggle("rotate");
    }

    // --- LÓGICA DEL CHATBOT ---
    function toggleChat() {
        const chat = document.getElementById('chatbot-window');
        chat.style.display = (chat.style.display === 'flex') ? 'none' : 'flex';
    }

    function handleKeyPress(e) {
        if (e.key === 'Enter') sendMessage();
    }

    function sendMessage() {
        const input = document.getElementById('user-input');
        const container = document.getElementById('chat-messages');
        const text = input.value.trim();
        
        if (text === "") return;

        // Mostrar mensaje del usuario
        appendMessage(text, 'user');
        input.value = "";

        // Respuesta simulada del bot
        setTimeout(() => {
            let response = "No estoy seguro de cómo ayudarte con eso todavía, pero puedes intentar preguntarme por tu 'saldo'.";
            
            if (text.toLowerCase().includes('saldo')) {
                response = "Para ver tu saldo real, dirígete al Dashboard. Actualmente estoy en fase de aprendizaje.";
            } else if (text.toLowerCase().includes('hola')) {
                response = "¡Hola de nuevo! ¿En qué puedo apoyarte con tus cuentas?";
            }

            appendMessage(response, 'bot');
        }, 800);
    }

    function appendMessage(text, side) {
        const container = document.getElementById('chat-messages');
        const div = document.createElement('div');
        div.className = `msg ${side}`;
        div.innerHTML = text;
        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    }
</script>