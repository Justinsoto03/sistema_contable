<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONTATECH PERÚ | Asesoría Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="http://localhost/contatech_db/assets/css/style.css">
</head>
<body>
    <header class="main-header">
        <div class="header-container">
            <div class="logo">
                <a href="http://localhost/contatech_db/index.php" style="text-decoration:none;">
                    <span class="brand-name">CONTATECH</span><span class="brand-sub">PERÚ</span>
                </a>
            </div>
            
            <nav class="main-nav">
                <div class="auth-buttons">
                    <?php if(isset($_SESSION['user_name'])): ?>
                        <span class="user-welcome">Hola, <strong><?php echo $_SESSION['user_name']; ?></strong></span>
                        <a href="http://localhost/contatech_db/controllers/auth_controller.php?action=logout" class="btn-login">Cerrar Sesión</a>
                    <?php else: ?>
                        <a href="http://localhost/contatech_db/views/login.php" class="btn-login">Iniciar Sesión</a>
                       <a href="http://localhost/contatech_db/views/login.php?mode=signup" class="btn-register">Comenzar Ahora</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>