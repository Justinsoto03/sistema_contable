<?php
session_start();
include '../config/db.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['user_id'])) {
    $usuario_id = $_SESSION['user_id']; // Identificamos al autor del movimiento
    // ... resto de tus variables (fecha, monto, etc.)
    
    try {
        $sql = "INSERT INTO movimientos (fecha, descripcion, tipo, monto, categoria, usuario_id) 
                VALUES (:fecha, :descripcion, :tipo, :monto, :categoria, :usuario_id)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':fecha' => $_POST['fecha'],
            ':descripcion' => $_POST['descripcion'],
            ':tipo' => $_POST['tipo'],
            ':monto' => $_POST['monto'],
            ':categoria' => $_POST['cuenta'] ?? 'General',
            ':usuario_id' => $usuario_id // Vinculamos el registro al usuario
        ]);

        header("Location: ../views/historial.php");
        exit();
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>