<?php
session_start();
include '../config/db.php'; // Usa tu conexión $pdo

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['respuesta' => 'Debes iniciar sesión para que pueda ayudarte.']);
    exit;
}

$mensaje = mb_strtolower($_POST['mensaje'] ?? '', 'UTF-8');
$uid = $_SESSION['user_id']; // ID del usuario actual
$nombre = $_SESSION['user_name']; // Nombre guardado en sesión
$respuesta = "";

// --- LÓGICA DE RESPUESTAS ---

// Respuesta sobre: ¿De qué trata la página?
if (preg_match('/(qué es|trata|página|para qué sirve|sistema)/', $mensaje)) {
    $respuesta = "Este es <strong>Accounting System</strong>, una plataforma para gestionar tus finanzas. Puedes registrar ingresos, gastos y ver tu saldo en tiempo real de forma segura.";
} 

// Respuesta sobre: Saldo y dinero
elseif (preg_match('/(saldo|dinero|tengo|cuánto)/', $mensaje)) {
    // Consulta real a la tabla movimientos filtrando por tu usuario_id
    $stmt = $pdo->prepare("SELECT 
        SUM(CASE WHEN tipo = 'ingreso' THEN monto ELSE 0 END) - 
        SUM(CASE WHEN tipo = 'egreso' THEN monto ELSE 0 END) as saldo 
        FROM movimientos WHERE usuario_id = ?");
    $stmt->execute([$uid]);
    $res = $stmt->fetch();
    $monto = number_format($res['saldo'] ?? 0, 2);
    $respuesta = "Hola $nombre, tu saldo actual es de <strong>S/ $monto</strong>.";
}

// Respuesta sobre: Gestión y consejos
elseif (preg_match('/(gestionar|consejo|ayuda|ahorrar)/', $mensaje)) {
    $respuesta = "Para gestionar mejor tu cuenta: <br>1. Registra tus movimientos diariamente.<br>2. Usa el <strong>Dashboard</strong> para ver tus meses con más gastos.<br>3. No olvides categorizar tus registros.";
}

// Saludo y respuesta por defecto
elseif (strpos($mensaje, 'hola') !== false) {
    $respuesta = "¡Hola $nombre! Soy tu asistente contable. ¿Quieres saber tu saldo o saber más sobre el sistema?";
} else {
    $respuesta = "No estoy seguro de eso. Prueba preguntándome: '¿Cuál es mi saldo?' o '¿De qué trata la página?'";
}

echo json_encode(['respuesta' => $respuesta]);