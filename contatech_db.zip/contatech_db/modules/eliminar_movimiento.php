<?php
session_start();
include '../config/db.php';

if (isset($_GET['id']) && isset($_SESSION['user_id'])) {
    $id = $_GET['id'];
    $usuario_id = $_SESSION['user_id'];

    try {
        // Borramos el movimiento pero verificamos que sea del usuario logueado
        $stmt = $pdo->prepare("DELETE FROM movimientos WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$id, $usuario_id]);

        header("Location: ../views/historial.php?delete=success");
        exit();
    } catch (PDOException $e) {
        die("Error al eliminar: " . $e->getMessage());
    }
} else {
    header("Location: ../views/historial.php");
}
?>