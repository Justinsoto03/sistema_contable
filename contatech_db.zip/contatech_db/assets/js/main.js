async function sendMessage() {
    const input = document.getElementById('user-input');
    const container = document.getElementById('chat-messages');
    const text = input.value.trim();
    
    if (text === "") return;

    // 1. Mostrar mensaje del usuario en la burbuja
    appendMessage(text, 'user');
    input.value = "";

    // 2. Enviar la pregunta al servidor (AJAX)
    try {
        const response = await fetch('../modules/chat_engine.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'mensaje=' + encodeURIComponent(text)
        });
        
        const data = await response.json();
        
        // 3. Mostrar la respuesta real que viene de la base de datos
        setTimeout(() => {
            appendMessage(data.respuesta, 'bot');
        }, 500);

    } catch (error) {
        appendMessage("Lo siento, tengo problemas para conectarme al servidor.", "bot");
    }
}

function appendMessage(text, side) {
    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = `msg ${side}`;
    div.innerHTML = text;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}