<?php include 'includes/header.php'; ?>

<main>
    <div class="hero-wrapper">
        <section class="hero-fullscreen">
    <img src="assets/img/portada.png" alt="Portada Contatech" class="hero-bg-img">
    
    <div class="hero-overlay"></div>
    
    <div class="hero-content-premium">
    <h1 class="animar-entrada">CLARIDAD EN FINANZAS <br><span>ELEVADAS.</span></h1>
    
    <p class="animar-entrada retraso-1">Potenciamos tu emprendimiento con tecnología y asesoría de primer nivel.</p>
    
    <div class="hero-buttons-premium animar-entrada retraso-2">
        <a href="http://localhost/contatech_db/views/login.php?mode=signup" class="btn-gold">Comenzar Ahora</a>
        <a href="#nosotros" class="btn-outline">Saber Más</a>
    </div>
</div>
    
</section>
    </div>
    </main>

    <section class="stats-bar">
        <div class="stat-item"> 
            <h3>+100</h3>
            <p>Emprendedores</p>
        </div>
        <div class="stat-item">
            <h3>100%</h3>
            <p>Online</p>
        </div>
        <div class="stat-item">
            <h3>Seguridad</h3>
            <p>En tus datos</p>
        </div>
    </section>

    <section id="nosotros" class="about-section">
    <div class="container">
        <span class="subtitle">Nuestra Misión</span>
        <h2 class="section-title">Especialistas en el éxito de las pequeñas empresas</h2>
        
        <div class="about-interactive-grid">
            <div class="info-card">
                <div class="card-content">
                    <h3>Propósito</h3>
                    <p>En <strong>CONTATECH PERÚ</strong>, creamos aplicativos digitales y servicios contables para guiar tu empresa desde cero.</p>
                </div>
            </div>

            <div class="info-card">
                <div class="card-content">
                    <h3>Facilidad</h3>
                    <p>Buscamos organizar tu información financiera y administrativa de manera clara, práctica y accesible.</p>
                </div>
            </div>

            <div class="info-card">
                <div class="card-content">
                    <h3>Visión Clara</h3>
                    <p>Comprende mejor tus ingresos, gastos y proyecciones de crecimiento en cada etapa de tu negocio.</p>
                </div>
            </div>

            <div class="info-card">
                <div class="card-content">
                    <h3>Toma de Decisiones</h3>
                    <p>Te brindamos la orientación básica para actuar con mayor seguridad, rapidez y orden estratégico.</p>
                </div>
            </div>
        </div>
    </div>
</section>
</main>

<footer class="main-footer">
    <div class="footer-container">
        <div class="footer-info">
            <a href="#" class="footer-logo">CONTATECH<span>PERÚ</span></a>
            <p>Transformando la contabilidad en una herramienta estratégica para el crecimiento de tu empresa.</p>
        </div>

        <div class="footer-links">
            <h4>Navegación</h4>
            <ul>
                <li><a href="#">Inicio</a></li>
                <li><a href="#">Contacto</a></li>
            </ul>
        </div>

        <div class="footer-contact">
            <h4>Contacto</h4>
            <p>Lima, Perú</p>
            <p>info@contatechperu.com</p>
            <div class="footer-social">
                <span>FB</span> <span>IG</span> <span>LK</span>
            </div>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>&copy;Justin | 2025 CONTATECH PERÚ. Todos los derechos reservados.</p>
    </div>
</footer>

<?php // include 'includes/footer.php'; ?>